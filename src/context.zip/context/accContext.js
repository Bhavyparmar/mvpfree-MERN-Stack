import { createContext } from "react";
//Creating context
const accContext=createContext();

export default accContext;