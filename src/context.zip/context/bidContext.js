import { createContext } from "react";
const bidContext=createContext();
export default bidContext
