import { createContext } from "react";
const admincontext=createContext();
export default admincontext
